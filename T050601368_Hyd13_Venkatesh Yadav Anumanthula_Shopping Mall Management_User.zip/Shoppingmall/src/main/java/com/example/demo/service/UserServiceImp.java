package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserRepository;
@Service
public class UserServiceImp implements UserService{

	@Autowired
	private UserRepository repository;
	@Override
	public List<UserEntity> listAll(){
		return repository.findAll();
	}
	@Override
	public UserEntity get(Long id) {
		return repository.findById(id).get();
	}
	@Override
	public void save(UserEntity user) {
		repository.save(user);
	}
	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}
	
     @Override
	 public  UserEntity updateUser(Long id, UserEntity user) {
	       UserEntity existUser = repository.findById(id).get();

	       if(Objects.nonNull(user.getName()) &&
	       !"".equalsIgnoreCase(user.getName())) {
	    	   existUser.setName(user.getName());
	       }

	       if(Objects.nonNull(user.getType()) &&
	               !"".equalsIgnoreCase(user.getType())) {
	    	   existUser.setType(user.getType());
	       }

	       if(Objects.nonNull(user.getPassword()) &&
	               !"".equalsIgnoreCase(user.getPassword())) {
	    	   existUser.setPassword(user.getPassword());
	       }

	       return repository.save(existUser);
	   }

}
