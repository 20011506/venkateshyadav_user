package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.UserEntity;

public interface UserService {

	public List<UserEntity> listAll();
	public UserEntity get(Long id);
	public void save(UserEntity user);
	public void delete(Long id);
	public  UserEntity updateUser(Long id, UserEntity user);
}
