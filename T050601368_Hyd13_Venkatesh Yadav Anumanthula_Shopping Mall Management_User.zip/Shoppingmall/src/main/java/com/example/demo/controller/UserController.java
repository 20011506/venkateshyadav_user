package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.UserEntity;
import com.example.demo.service.UserService;


@RestController
public class UserController {

	@Autowired
	private UserService service;
	
	//Retrieval                  // to service class implementations/operations 
	@GetMapping("/user")
	public List<UserEntity> list(){
		return service.listAll();
		
	}
	//Retrieve By Id
	@GetMapping("/user/{id}")
	public UserEntity get(@PathVariable Long id){
		return service.get(id);
	}
		
		// Create 
		@PostMapping("/user")
		public void add(@RequestBody UserEntity user)
		{
		service.save(user);	
		}
		
		//update
		@PutMapping("/user/{id}")
		public UserEntity updateUser(@PathVariable("id") Long id,@RequestBody UserEntity user){
			return service.updateUser(id,user);
			
		}
		
		//delete
		@DeleteMapping("/user/{id}")
		public String delete(@PathVariable Long id) {
			service.delete(id);
			return "Succesfully deleted";
		}
			
		
}
