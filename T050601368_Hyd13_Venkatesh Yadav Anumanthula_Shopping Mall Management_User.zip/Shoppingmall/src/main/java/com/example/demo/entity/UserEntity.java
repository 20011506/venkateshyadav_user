package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class UserEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long id;
	private String name;
	private String type;
	private String password;
	public UserEntity(Long id, String name, String type, String password) { // parameterized constructor
		super();  
		this.id = id;
		this.name = name;
		this.type = type;
		this.password = password;
	}
	public UserEntity() {  // unparameterized constructor 
		super();
	}
	public Long getId() {  // getters
		return id;
	}
	public void setId(Long id) { // setters
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserEntity [id=" + id + ", name=" + name + ", type=" + type + ", password=" + password + "]";
	}

	
}
